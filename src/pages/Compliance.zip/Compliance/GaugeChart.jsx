import React, { useEffect } from 'react';
import styles from './Compliance.module.css';

const GaugeChart = () => {
  useEffect(() => {
    const loadScript = (src) => {
      return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        script.onload = resolve;
        script.onerror = reject;
        document.body.appendChild(script);
      });
    };

    const initChart = async () => {
      try {
        await Promise.all([
          loadScript('https://cdn.amcharts.com/lib/5/index.js'),
          loadScript('https://cdn.amcharts.com/lib/5/xy.js'),
          loadScript('https://cdn.amcharts.com/lib/5/radar.js'),
          loadScript('https://cdn.amcharts.com/lib/5/themes/Animated.js')
        ]);

        console.log('AmCharts scripts loaded');
        
        const am5 = window.am5;
        const am5themes_Animated = window.am5themes_Animated;
        const am5radar = window.am5radar;
        const am5xy = window.am5xy;

        if (!am5 || !am5themes_Animated || !am5radar || !am5xy) {
          console.error('One or more AmCharts modules are not available');
          return;
        }

        console.log('AmCharts modules are available');

        const root = am5.Root.new('chartdiv');

        root.setThemes([
          am5themes_Animated.new(root)
        ]);

        const chart = root.container.children.push(am5radar.RadarChart.new(root, {
          panX: false,
          panY: false,
          startAngle: 160,
          endAngle: 380
        }));

        const axisRenderer = am5radar.AxisRendererCircular.new(root, {
          innerRadius: -40
        });

        const xAxis = chart.xAxes.push(am5xy.ValueAxis.new(root, {
          maxDeviation: 0,
          min: 0,
          max: 100,
          strictMinMax: true,
          renderer: axisRenderer
        }));

        const customLabels = [0, 50, 100];
        customLabels.forEach(value => {
          const axisRange = xAxis.createAxisRange(xAxis.makeDataItem({
            value: value,
            endValue: value
          }));

          axisRange.get('label').setAll({
            text: value.toString(),
            inside: true,
            radius: -30,
            fill: root.interfaceColors.get('background')
          });
        });

        const axisDataItem = xAxis.makeDataItem({});

        const clockHand = am5radar.ClockHand.new(root, {
          pinRadius: am5.percent(20),
          radius: am5.percent(100),
          bottomWidth: 10
        });

        const bullet = axisDataItem.set('bullet', am5xy.AxisBullet.new(root, {
          sprite: clockHand
        }));

        xAxis.createAxisRange(axisDataItem);

        axisDataItem.set('value', 70);

        bullet.get('sprite').on('rotation', function () {
          const value = axisDataItem.get('value');
          let fill = am5.color(0x000000);
          xAxis.axisRanges.each(function (axisRange) {
            if (value >= axisRange.get('value') && value <= axisRange.get('endValue')) {
              fill = axisRange.get('axisFill').get('fill');
            }
          });

          clockHand.pin.animate({ key: 'fill', to: fill, duration: 500, easing: am5.ease.out(am5.ease.cubic) });
          clockHand.hand.animate({ key: 'fill', to: fill, duration: 500, easing: am5.ease.out(am5.ease.cubic) });
        });

        const bandsData = [
          { title: 'Low', color: '#ff0000', lowScore: 0, highScore: 33 },
          { title: 'Medium', color: '#ffeb3b', lowScore: 34, highScore: 66 },
          { title: 'High', color: '#4caf50', lowScore: 67, highScore: 100 }
        ];

        bandsData.forEach(data => {
          const axisRange = xAxis.createAxisRange(xAxis.makeDataItem({
            value: data.lowScore,
            endValue: data.highScore
          }));

          axisRange.get('axisFill').setAll({
            visible: true,
            fill: am5.color(data.color),
            fillOpacity: 0.8
          });

          axisRange.get('label').setAll({
            text: data.title,
            inside: true,
            radius: 15,
            fontSize: '0.9em',
            fill: root.interfaceColors.get('background')
          });
        });

        chart.appear(1000, 100);
      } catch (error) {
        console.error('Failed to load AmCharts scripts', error);
      }
    };

    initChart();
  }, []);

  return (
    <div id="chartdiv" className={styles.chart_container}>
    </div>
  );
};

export default GaugeChart;
